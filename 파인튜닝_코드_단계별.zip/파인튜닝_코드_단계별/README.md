# 파인튜닝 프로젝트 코드 — 시간 순서 · 단계별 아카이브

> 도메인 특화 사내 AI(국가공무원 복무규정 Q&A)를 만든 전체 코드를,
> 진행한 시간 순서 = 단계별로 폴더에 나눠 담은 것이다.
> 각 폴더는 그 단계에서 만들었거나 처음 쓴 스크립트를 담는다.

## 진행 순서 한눈에

```
00_공통            →  1단계(run1~3)  →  2단계 RAG  →  3단계 결합(run4)  →  4단계 추론강화(run5~7)
설정·유틸             파인튜닝            검색            근거 다루는 행동      CoT·벤치마크·DPO·자기개선
```

실행 순서(파이프라인):
parse_doc → (Q&A 생성) → verify_qa → make_augmented_qa → build_dataset →
validate_data → prepare_data → train.sh → embed_chunks → eval_retrieval →
rag_chat → build_rag_dataset → train_rag → build_cot_dataset → train_rag(run5) →
eval_benchmark → fuse(--dequantize) → build_dpo_pairs → train_dpo →
self_improve_generate → self_improve_filter → (run7 학습)

---

## 00_공통 — 설정과 유틸 (전 단계 공유)

| 파일 | 한 일 |
|---|---|
| `common.py` | 설정 로드, 상대→절대 경로 변환, JSONL 읽기/쓰기. 모든 스크립트가 import |
| `config.yaml` | 사람이 고치는 유일한 설정(모델·데이터·검증·학습·RAG). 나머지 설정은 파생물 |
| `fuse.sh` | 어댑터를 원본에 병합. **DPO용 fused_run5는 반드시 `--dequantize`(16bit)** |
| `chat.sh` | 학습한 어댑터로 바로 대화 테스트 |

## 1단계_파인튜닝_run1-3 — 데이터가 전부다

run1(과적합 목격) → run2(사실 밀도 진단) → run3(증강 성공, 0/4→4/4)

| 파일 | 한 일 |
|---|---|
| `parse_doc.py` | 규정 원문을 "제N조" 조각으로 분해. 각 조각이 근거 앵커(chunk_id) |
| `verify_qa.py` | 생성된 Q&A 검수. 답변 숫자가 원문에 있는지 대조해 환각 차단 |
| `make_augmented_qa.py` | **run3 처방** — 사실 하나를 질문 표현 여럿으로 증강(사실 밀도) |
| `make_refusal_data.py` | 거절 예시 생성. "규정에 없으면 물러서는" 행동을 가르침(환각 방어) |
| `build_dataset.py` | 도메인 + 거절 + replay를 비율로 혼합 |
| `validate_data.py` | Pydantic 검증. 한글/한자 비율로 중국어 오염 차단(망각 방어) |
| `prepare_data.py` | **챗 템플릿 변환(to_chat)** + train/valid/holdout 분할. 지난 실패의 직접 처방 |
| `train.sh` | mlx-lm LoRA 학습 실행기(config→설정 생성→학습). batch 자동 축소 포함 |
| `evaluate.py` | 원본 vs 학습 모델을 표준 문항으로 행동 채점(키워드·중국어·거절) |

## 2단계_RAG — 검색은 행렬곱 한 줄

파인튜닝이 못 하는 "정확한 사실"을 검색으로 채운다.

| 파일 | 한 일 |
|---|---|
| `embed_chunks.py` | 조문을 임베딩(bge-m3)해 인덱스로 저장. 의미 좌표 만들기 |
| `rag_search.py` | 검색 핵심. `vectors @ q_vec` 한 줄로 코사인 유사도 top-k |
| `eval_retrieval.py` | 검색 정확도(hit@k). 합성 Q&A의 chunk_id를 정답지로 재활용 |
| `rag_chat.py` | 검색된 근거를 프롬프트에 주입해 답. `--base/--adapter/--model` 조합 |

## 3단계_결합_run4 — 근거를 다루는 행동을 가르치다

run4(행동 충돌 실패) → run4b(정책 일관화 성공)

| 파일 | 한 일 |
|---|---|
| `build_rag_dataset.py` | "질문+검색 근거→행동" 학습 데이터. 년차류 정책 일관화(RE_YEONCHA) |
| `train_rag.sh` | RAG 형식 데이터로 LoRA 학습(run4b·run5 공용, adapter만 바꿔 재사용) |

## 4단계_추론강화_run5-7 — 빅테크 후학습 코스

CoT 증류(run5) → 벤치마크 → DPO(run6) → 자기개선(run7)

| 파일 | 한 일 |
|---|---|
| `build_cot_dataset.py` | **run5** — 풀이 과정(CoT)을 코드로 생성. 숫자 홀드아웃 설계 |
| `eval_benchmark.py` | KMMLU 벤치마크. 일반 능력 역행 없음(부작용) 검사 |
| `build_dpo_pairs.py` | **run6** — 관측된 실패 4유형을 rejected로 재현한 선호 쌍 |
| `train_dpo.py` | mlx-tune DPO 학습 + 16bit 병합 저장(fused_run6). 재양자화 손상 회피 |
| `self_improve_generate.py` | **run7** — 모델이 새 문제에 답 여러 개 생성(temp 0.7) |
| `self_improve_filter.py` | 생성 답안 채점(정답+궤적+형식+언어). 합격작만 다음 학습 재료 |

---

## 아카이브 정확도에 대한 메모 (정직하게)

이 아카이브는 작업 워크스페이스가 초기화되어, **대화 기록에 남은 코드로 다시 생성**한 것이다.

- **원본 그대로**: common, parse_doc, verify_qa, make_refusal_data, build_dataset,
  validate_data, prepare_data, train.sh, embed_chunks, rag_search, eval_retrieval,
  rag_chat, build_rag_dataset, build_cot_dataset, eval_benchmark, build_dpo_pairs,
  train_dpo, self_improve_generate, self_improve_filter → 세션 중 읽어둔 내용 그대로.
- **재구성(설계대로 복원, 정본은 맥)**: `config.yaml`, `evaluate.py`, `train_rag.sh`,
  `fuse.sh`, `chat.sh`, 그리고 `make_augmented_qa.py`의 병가·지각 파트(연가 파트는 원본).
  각 파일 상단에 그 사실을 표기했다.
- **이 아카이브에 없음(맥 원본에만 있는 초기 스캐폴딩)**: `download_data.py`,
  `make_sample_data.py`, `build_testset.py`, `step1_baseline.py` — 내용을 정확히
  복원할 수 없어 지어내지 않았다. 맥 `~/qwen-domain-ft/scripts/`에 있다.

정본(실제로 돌아가는 코드)은 언제나 맥 `~/qwen-domain-ft/`이다.
